<footer>        
    <a href="http://www.malasngoding.com">MalasNgoding</a>
    
  </footer> 
 </div> 
</body> 
</html>